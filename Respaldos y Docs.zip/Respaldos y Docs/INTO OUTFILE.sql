USE sistemagestionflotillas;
SELECT * FROM conductor INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/conductor.txt' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n';

SELECT * FROM documento INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/documento.txt' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n';

SELECT * FROM flotilla INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/flotilla.txt' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n';

SELECT * FROM mantenimiento INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/mantenimiento.txt' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n';

SELECT * FROM ruta INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/ruta.txt' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n';

SELECT * FROM transaccioncombustible INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/transaccioncombustible.txt' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n';

SELECT * FROM vehiculo INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/vehiculo.txt' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n';




SELECT @@secure_file_priv;