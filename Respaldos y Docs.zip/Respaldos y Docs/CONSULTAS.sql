SELECT 
    v.vehiculoId, 
    v.marca, 
    v.modelo, 
    r.rutaId, 
    r.horaInicio, 
    r.horaFin, 
    r.ubicacionInicio, 
    r.ubicacionFin
FROM 
    LCS1Principal.vehiculo v
JOIN 
    LCS3Rutas.ruta r 
ON 
    v.vehiculoId = r.vehiculoId;

-- ------------------------------------- --
    SELECT 
    d.documentoId, 
    d.tipo, 
    d.fechaVencimiento, 
    c.conductorId, 
    c.nombre, 
    c.numeroLicencia
FROM 
    LCS1Principal.documento d
JOIN 
    LCS3Rutas.conductor c 
ON 
    d.vehiculoId = c.conductorId;