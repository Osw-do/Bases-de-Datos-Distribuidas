DELIMITER //

CREATE TRIGGER after_vehiculo_insert
AFTER INSERT ON LCS1Principal.vehiculo
FOR EACH ROW
BEGIN
    -- Insertar en LCS2Mantenimiento.vehiculo
    INSERT INTO LCS2Mantenimiento.vehiculo (vehiculoId, flotillaId, tipo, modelo, marca, anio, estado, fechaVerificacion)
    VALUES (NEW.vehiculoId, NEW.flotillaId, NEW.tipo, NEW.modelo, NEW.marca, NEW.anio, NEW.estado, NEW.fechaVerificacion);

    -- Insertar en LCS3Rutas.vehiculo
    INSERT INTO LCS3Rutas.vehiculo (vehiculoId, flotillaId, tipo, modelo, marca, anio, estado, fechaVerificacion)
    VALUES (NEW.vehiculoId, NEW.flotillaId, NEW.tipo, NEW.modelo, NEW.marca, NEW.anio, NEW.estado, NEW.fechaVerificacion);
END //

DELIMITER ;

DELIMITER //

CREATE TRIGGER after_vehiculo_update
AFTER UPDATE ON LCS1Principal.vehiculo
FOR EACH ROW
BEGIN
    -- Actualizar en LCS2Mantenimiento.vehiculo
    UPDATE LCS2Mantenimiento.vehiculo
    SET 
        flotillaId = NEW.flotillaId,
        tipo = NEW.tipo,
        modelo = NEW.modelo,
        marca = NEW.marca,
        anio = NEW.anio,
        estado = NEW.estado,
        fechaVerificacion = NEW.fechaVerificacion
    WHERE vehiculoId = NEW.vehiculoId;

    -- Actualizar en LCS3Rutas.vehiculo
    UPDATE LCS3Rutas.vehiculo
    SET 
        flotillaId = NEW.flotillaId,
        tipo = NEW.tipo,
        modelo = NEW.modelo,
        marca = NEW.marca,
        anio = NEW.anio,
        estado = NEW.estado,
        fechaVerificacion = NEW.fechaVerificacion
    WHERE vehiculoId = NEW.vehiculoId;
END //

DELIMITER ;

DELIMITER //

CREATE TRIGGER after_vehiculo_delete
AFTER DELETE ON LCS1Principal.vehiculo
FOR EACH ROW
BEGIN
    -- Eliminar en LCS2Mantenimiento.vehiculo
    DELETE FROM LCS2Mantenimiento.vehiculo
    WHERE vehiculoId = OLD.vehiculoId;

    -- Eliminar en LCS3Rutas.vehiculo
    DELETE FROM LCS3Rutas.vehiculo
    WHERE vehiculoId = OLD.vehiculoId;
END //

DELIMITER ;